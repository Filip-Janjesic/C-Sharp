﻿using Valid_Parentheses;

var task = new Solution();
bool result = task.IsValid("()[]{}");
Console.WriteLine(result);
