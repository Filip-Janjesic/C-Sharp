﻿using Car_Fleet;

var task = new Solution();
int result = task.CarFleet(12, [10, 8, 0, 5, 3], [2, 4, 1, 1, 3]);
Console.WriteLine(result);
