﻿using Largest_Rectangle_in_Histogram;

var task = new Solution();
int result = task.LargestRectangleArea([2, 1, 5, 6, 2, 3]);
Console.WriteLine(result);
