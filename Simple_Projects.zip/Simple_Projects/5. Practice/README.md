# Stack

## Easy
- Merge Two Sorted Lists
- Valid Parentheses

## Medium
- Car Fleet
- Daily Temperatures
- Evaluate Reverse Polish Notation
- Generate Parentheses
- Min Stack

## Hard
- Largest Rectangle in Histogram
