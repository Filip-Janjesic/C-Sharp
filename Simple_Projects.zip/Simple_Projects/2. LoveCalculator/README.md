# LoveCalculator
A simple love calculator
