# Privacy Policy

The Simple Screen Recorder app does not collect or transmit information from the user. Recorded videos are saved locally on the user's device.

Any information that is received is through Microsoft's reporting information as outlined in [Microsoft's developer agreement](https://docs.microsoft.com/en-us/legal/windows/agreements/app-developer-agreement), specifically section 9.