# Simple Screen Recorder

A simple screen recorder using both the Windows.Graphics.Capture and Windows.Media.Transcoding APIs.

<a href='//www.microsoft.com/store/apps/9N5MVVBD0TGW?cid=storebadge&ocid=badge'><img src='https://developer.microsoft.com/store/badges/images/English_get-it-from-MS.png' alt='English badge' height='50px'/></a>

![A screenshot of SimpleRecorder.](https://user-images.githubusercontent.com/7089228/140004710-1f043ae2-e530-4840-8293-c5d7778e2af3.png)
